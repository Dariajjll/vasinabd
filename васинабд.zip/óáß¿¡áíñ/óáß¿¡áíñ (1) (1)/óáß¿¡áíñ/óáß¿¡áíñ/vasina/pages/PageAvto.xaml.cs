﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using vasina.classes;

namespace vasina.pages
{
    /// <summary>
    /// Логика взаимодействия для PageAvto.xaml
    /// </summary>
    public partial class PageAvto : Page
    {
        public PageAvto()
        {
            InitializeComponent();
            DtgAvto.ItemsSource = TestDBEntities.GetContext().avtom.ToList();
        }

        private void SearAvto_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgAvto.ItemsSource != null)
            {
                DtgAvto.ItemsSource = TestDBEntities.GetContext().avtom.Where(x => x.marka.ToLower().Contains(SearAvto.Text.ToLower())).ToList();
            }
            if (SearAvto.Text.Count() == 0) DtgAvto.ItemsSource = TestDBEntities.GetContext().avtom.ToList();
        }
    }
}
